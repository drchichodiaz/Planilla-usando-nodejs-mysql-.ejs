
/*
 * GET users listing.
 */

exports.list = function(req, res){

  req.getConnection(function(err,connection){
       
        var query = connection.query('SELECT * FROM empleado',function(err,rows)
        {
            
            if(err)
                console.log("Error Selecting : %s ",err );
     
            res.render('empleados',{page_title:"Customers - Node.js",data:rows});
                
           
         });
         
         //console.log(query.sql);
    });
  
};

exports.add = function(req, res){
  res.render('add_empleado',{page_title:"Aniadir Empleados"});
};

exports.edit = function(req, res){
    console.log("Esta pasando por aqui 1 "+ req.params.id);
    var ID = req.params.id;
    
    req.getConnection(function(err,connection){
       
        var query = connection.query('SELECT * FROM empleado WHERE ID = ?',[ID],function(err,rows)
        {
            
            if(err)
                console.log("Error Selecting : %s ",err );
     
            console.log("Esta pasando por aqui 2");
            res.render('edit_empleado',{page_title:"Editar Empleados",data:rows});
                
           
         });
         
         //console.log(query.sql);
    }); 
};

/*Save the empleado*/
exports.save = function(req,res){
    
    var input = JSON.parse(JSON.stringify(req.body));
    req.getConnection(function (err, connection) {
        
        var data = {
            
            nombre    : input.nombre,
            apellido : input.apellido,
            cedula    : input.cedula,
            clave    : input.clave,
            cargo    : input.cargo,
            anos    : input.anos,
            otros_ingresos    : input.otros_ingresos
        };
        
        var query = connection.query("INSERT INTO empleado set ? ",data, function(err, rows)
        {
  
          if (err)
              console.log("Error insertando : %s ",err );
         
          res.redirect('/empleados');
          
        });
        
       // console.log(query.sql); get raw query
    
    });
};

exports.save_edit = function(req,res){
    
    var input = JSON.parse(JSON.stringify(req.body));
    var ID = req.params.id;
    
    req.getConnection(function (err, connection) {
        
        var data = {
            
            nombre    : input.nombre,
            apellido : input.apellido,
            cedula    : input.cedula,
            clave    : input.clave,
            cargo    : input.cargo,
            anos    : input.anos,
            otros_ingresos    : input.otros_ingresos
        
        };
        
        connection.query("UPDATE empleado set ? WHERE ID = ? ",[data,ID], function(err, rows)
        {
  
          if (err)
              console.log("Error Updating : %s ",err );
         
          res.redirect('/empleados');
          
        });
    
    });
};


exports.delete_empleado = function(req,res){
          
     var ID = req.params.id;
    
     req.getConnection(function (err, connection) {
        
        connection.query("DELETE FROM empleado  WHERE ID = ? ",[ID], function(err, rows)
        {
            
             if(err)
                 console.log("Error deleting : %s ",err );
            
             res.redirect('/empleados');
             
        });
        
     });
};


